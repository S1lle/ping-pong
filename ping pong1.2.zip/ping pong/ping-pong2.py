
from pygame import *
from random import randint

w, h = 1000, 800
window = display.set_mode((w, h))
Fps = 60
clock = time.Clock()
bg = transform.scale(image.load("bg.jpg"), (w, h))


class Main(sprite.Sprite):
    def __init__(self, m_image, m_x, m_y, m_speed):
        super().__init__()
        self.image = transform.scale(image.load(m_image), (150, 150))
        self.rect = self.image.get_rect()
        self.rect.x = m_x
        self.rect.y = m_y
        self.speed = m_speed

    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))


class Rocket1(Main):
    def update(self):
        keys = key.get_pressed()
        if keys[K_UP]:
            self.rect.y -= self.speed
        if keys[K_DOWN]:
            self.rect.y += self.speed


class Rocket2(Main):
    def update(self):
        keys = key.get_pressed()
        if keys[K_w]:
            self.rect.y -= self.speed
            self.rect.x -= 0
        if keys[K_s]:
            self.rect.y += self.speed
            self.rect.x += 0
        
        


rocket1 = Rocket2("rocket2.png", 30, 10, 10)
rocket2 = Rocket1("rocket.png", 790, 30, 10)
ball = Main("ball.png", 400, 400, 2)

final = False
game = True

speed_x = 3
speed_y = 3
height = 790
height2 = 10

font.init()
text = font.Font(None, 80)
lose1 = text.render("Гравець 1 програв!", True, (255, 255, 255))
lose2 = text.render("Гравець 2 програв!", True, (255, 255, 255))
resrtx = text.render("Натисніть R, щоб почати знову", True, (255, 255, 255))
speed_x = 3
speed_y = 3
while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
        elif e.type == KEYDOWN:
            if e.key == K_r and final == True:
                final = False
                ball.rect.x = 400
                ball.rect.y = 400
                speed_x = 3
                speed_y = 3

    if final != True:
        window.blit(bg, (0, 0))
        rocket1.update()
        rocket1.reset()
        rocket2.update()
        rocket2.reset()
        ball.reset()
        ball.rect.x += speed_x  
        ball.rect.y += speed_y

        if sprite.collide_rect(rocket1, ball) or sprite.collide_rect(rocket2, ball):
            speed_x *= -1
            speed_y *= 1.01

        if ball.rect.y > h-130 or ball.rect.y < 0:
            speed_y *= -1
            speed_x *= 1.01
        if ball.rect.x < 0:
            final = True
            window.blit(lose1, (200, 400))

        if ball.rect.x > 800:
            final = True
            window.blit(lose2, (200, 400))

    else:
        rocket1.reset()
        rocket2.reset()
        ball.reset()
        window.blit(resrtx, (100, 200))
    clock.tick(Fps)
    display.update()